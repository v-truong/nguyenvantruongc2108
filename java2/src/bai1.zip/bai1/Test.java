package bai1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Test {
    List<Opportunity> Opp=new ArrayList<>();
    public static void main(String[] args) throws IOException {
        opportunities o =new opportunities();
        FileWriter writer = new FileWriter("D:/hocjava/java2/src/bai1/data_file.dat");  
        BufferedWriter buffer = new BufferedWriter(writer);  
        
        o.add();
        o.writeFile();
       

    }
   
}
