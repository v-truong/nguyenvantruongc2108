package com.example.bai2;

import java.util.Random;
import java.util.Set;

public class Thread1 extends Thread{

    public void run() {
        try{
            Thread.sleep(2000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Random random=new Random();
        int a = random.nextInt(6);
        TestThread.giatriRanDom=a;

        Set<String>  day = TestThread.today.keySet();
        Object[]  objectday = day.toArray();
        String b = objectday[a].toString();
        System.out.println("---tieng anh:"+b);

    }
}
