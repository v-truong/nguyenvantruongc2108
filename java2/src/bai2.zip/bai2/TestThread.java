package com.example.bai2;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestThread extends Thread{
    public static Map<String,String> today=new TreeMap<String,String>();
    public static int giatriRanDom = 0;
    
    public static void main(String[] args) {
        today.put("Monday" , "thu 2");
        today.put("Tuesday" , "thu 3");
        today.put("Wednesday" , "thu 4");
        today.put("Thursday" , "thu 5");
        today.put("Friday" , "thu 6");
        today.put("Saturday" , "thu 7");
        today.put("Sunday" , "chu nhat");
        
        Thread1 th=new Thread1();
        th.start();
        Thread2 th2 =new Thread2();
        th2.start();
    }
}
