package com.example.bai2;

import java.util.Set;

public class Thread2 extends Thread{

    public void run() {
        int a = TestThread.giatriRanDom;
        Set<String> setday = TestThread.today.keySet();
        Object[]  objectsday = setday.toArray();
        String b = objectsday[a].toString();

        String date = TestThread.today.get(b);
        System.out.println("vietnam : "+date);
    }
}
