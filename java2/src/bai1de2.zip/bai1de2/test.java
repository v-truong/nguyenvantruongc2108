package bai1de2;

public class test {
    public static void main(String[] args) {
        Album a=new Album();
        AlbumManagement al=new AlbumManagement();
        
        al.initialeAlbumnList();
    }
}
